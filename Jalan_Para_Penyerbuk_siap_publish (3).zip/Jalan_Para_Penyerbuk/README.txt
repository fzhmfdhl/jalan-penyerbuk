JALAN PARA PENYERBUK - boardgame virtual (2-4 pemain, satu perangkat)
=====================================================================

ISI PAKET
- index.html  : GAME LENGKAP. Satu file, sudah berisi semua gambar, musik, dan suara.
                Inilah satu-satunya file yang perlu di-upload agar game bisa dimainkan online.
- aset/       : bahan mentah (papan, petak, karakter, kartu, efek kartu, suara) untuk
                arsip atau kalau nanti ingin mengganti sesuatu. Gambar disimpan sebagai WebP
                (transparansi tetap, ukuran jauh lebih kecil). TIDAK perlu di-upload.

UPLOAD KE GITHUB
- Yang wajib hanya index.html (sekitar 3 MB). Batas upload lewat web GitHub: 25 MB per file dan
  100 file per sekali upload, jadi folder aset/ sebaiknya diunggah terpisah atau lewat git.

CARA PUBLISH (pilih salah satu, semuanya gratis)
1) Netlify Drop (paling mudah, tanpa akun untuk uji coba)
   - Buka https://app.netlify.com/drop
   - Seret folder ini (atau hanya file index.html) ke halaman itu.
   - Kamu langsung mendapat link yang bisa dibagikan.
2) GitHub Pages
   - Buat repository baru, upload index.html ke root.
   - Settings > Pages > Source: "Deploy from a branch" > branch main, folder / (root).
   - Link: https://NAMAKAMU.github.io/NAMA-REPO/
3) Cloudflare Pages atau Vercel
   - Buat project baru, upload folder ini. Build command dikosongkan, output directory: .
4) Hosting biasa (cPanel dll.)
   - Upload index.html ke folder public_html.

ATURAN YANG DIPAKAI (Aturan Game Board FIX TM1, versi layar)
- 2-4 pemain di satu layar. Urutan main diundi di awal. Tiap pemain memilih karakter.
- Juara: tiga pemain pertama yang masuk Taman Emas (bayar 3 Nektar di Gerbang Taman Emas)
  menjadi juara 1, 2, 3. Pion yang masuk keluar dari papan. Game selesai saat juara terakhir masuk.
- Efek petak berantai: kalau efek memindahkan pion, efek petak tujuan ikut dijalankan.
- Jebakan hanya aktif saat pion MENDARAT di petaknya (dilewati = tidak aktif). Dipasang di petak Kosong yang kosong.
- Jerat: terjebak sampai lempar dadu genap. Hujan: sampai lempar 4 ke atas. Kepompong dan Getah Lengket:
  lewat 1 giliran lalu otomatis bebas (boleh memakai kartu di giliran yang dilewati).
- Kartu pengubah dadu (Angin Belakang, Madu Energi, Coba Lagi, Dadu Plus) ditawarkan SETELAH dadu dilempar.
- Maksimal 1 kartu per giliran (Tangkis tidak dihitung), maksimal 5 kartu di tangan, ronde 1 tanpa kartu Serang.
- Belum diterapkan: batas waktu giliran dan peran gamemaster (itu untuk permainan langsung).

CATATAN PENTING
- Game berjalan sepenuhnya di browser. Tidak butuh server, database, atau API key.
- Pemain bergantian di SATU layar (pass-and-play). Belum ada multiplayer antar-HP.
- Musik dan suara baru berbunyi setelah layar disentuh/diklik sekali (aturan browser).
- Tombol Musik / SFX / Suara ada di menu atas dan pilihannya diingat di browser.
- Suara bicara cadangan memakai suara bawaan perangkat (bahasa Indonesia bila tersedia),
  dipakai hanya untuk kejadian yang belum punya klip. Kartu Semprotan Pestisida
  (mundur dua langkah) masih memakai suara cadangan ini.
- Klip suara dibuat dengan ElevenLabs. Cek ketentuan lisensi plan kamu bila game
  akan dipublikasikan luas atau dikomersialkan (plan gratis biasanya punya batasan).

NAMA FILE SUARA (di aset/suara) = KUNCI DI DALAM GAME
- dice1..dice6 : angka dadu          - defend / fx_pantul : tangkisan / dipantulkan
- giliran      : pergantian giliran  - fx_menang          : menang
- name_<karakter> : nama karakter (lebah, kupukupu, kolibri, kumbang, capung, tawon,
                    ngengat, semut, belalang, kelelawar)
- fx_<efek>    : efek kartu serang, petak, Lalat, Bunga, Nektar
- cast_<kartu> : pengumuman saat kartu non-serang dipakai
Untuk mengganti suara, kirim file baru dengan nama yang sama ke asisten yang membangun
game ini, supaya klipnya dipadatkan dan ditanam ulang ke index.html.
